# PHP 5.6.40 community-backport: build and validation

Built 25 October 2026 (Asia/Karachi), using Visual Studio Express 2012 for Windows Desktop.

## Package

`php-5.6.40-community-backport-Win32-VC11-x86.zip` — Release, VC11, x86, Thread Safe, Apache 2.4 handler, CLI and CGI, with 32 snapshot extensions. No active `php.ini` is bundled. Existing XAMPP and earlier release ZIP hashes are unchanged.

## Exact source and patch

- Source: https://github.com/php/php-src.git
- Ref: `php-5.6.40`
- Source commit: `4b8f72da5dfb201af4e82dee960261d8657e414f`
- Reported PHP version: `5.6.40`
- Patch: `php-5.6-community-backport.patch`
- Patch repository commit: `44d89a8ef15ecaded6ef441b4afea5653eb1f8c9`
- Original local patch SHA-256: `73cf8d6b148294a9eb8072f8cbed8b34307339ca9f97a0ddebcf8950953bec11`
- LF-normalized applied patch SHA-256: `abcb401aef115604f5ccedce32581872e6a993069ae74eae255f0706faea026c`
- Upload progress: **force-disabled**. Ordinary uploads were verified.

This build uses its own clean source checkout and its own compiler outputs. The community source was cloned from the original PHP 5.6.40 commit already downloaded for the preceding build. The Remi sources were cloned from a newly downloaded security-backports branch at the pinned commit above. Patch CRLF line endings were converted to LF; no patch code changes were made. Source diffs before and after validation match exactly.

## Build

Compiler: `17.00.50727.1 for x86`. Existing SDK: `php-sdk-binary-tools-20110915.zip`. Existing dependency tree: `C:\php-sdk\phpdev\vc11\x86\deps`, from `deps-5.6-vc11-x86_2018-12.7z` (SHA-256 `641a4f39f7a7fff4fbcfdccabc12e0845b451d8cdb1e834a937488a40b2539ab`). The source is kept separately under `builds/community-backport/source`.

```bat
builds\build.cmd community-backport configure
builds\build.cmd community-backport snapshot
```

Configuration follows the prior guide; `--with-php-build` supplies the existing dependency path and `--with-mp=2` limits compiler concurrency. `nmake snap` compiles its prerequisites and packages them directly; there was no need to run a redundant earlier `nmake` pass. Exact arguments are in `build-info.json`. Snapshot exit code: 0.

The legacy packager emits an empty-PECL archive warning and warnings about dependency debug symbols and uncollected system/client DLLs. The main runtime archive passed its integrity and required-file checks. VC2012 x86 runtime libraries must be available on a destination machine.

## Validation

- Six smoke checks passed, including correct version/architecture/thread safety, normal CGI upload with 3,000 irrelevant MIME headers, expected progress behavior, session round trip, and immediate memory-limit termination without running a registered shutdown callback.
- Original bundled PHPT tests: **35 passed, 1 skipped, 0 failed, 0 warned**. The debug-build-only test is skipped in this Release build.
- Apache 2.4.12 Win32 loaded the new PHP module using an isolated workspace configuration: `Syntax OK`, exit 0. Apache was not started or restarted.
- Previously available XAMPP CLI static modules are retained.
- Dynamic extensions: 28/32 loaded without warnings. SNMP loads but reports missing MIB data; InterBase, PDO Firebird and Sybase CT require external client DLLs. These optional extensions are not enabled by a bundled active configuration.
- ZIP executable/DLL bytes match the extracted binaries used in validation.
- Runtime source diff matches only the requested patch; XAMPP files and prior ZIPs match their recorded baseline hashes.

Windows test-harness copies used: **no**. Where present, `tests/windows` preserves separate PHPT copies with the Windows `proc_open` bypass-shell option and a separate runner fixes extension detection when runner and target are the same `-n` binary. Test payloads and expected results were preserved; the original source tests and runtime were not edited. Original failed runs and the adjustment diff are retained alongside final results.

These are targeted build/runtime checks, not a complete security audit or full PHP test suite. PHP 5.6 and the historical dependency libraries remain unsupported. Live web requests, concurrent Apache behavior, Symfony acceptance, external databases/services and the Linux-only feedpost test harness were not exercised.

## Records

The ZIP contains `build-info/` with revisions, exact patches, source diff, compiler identity, validation and these notes. Full logs, selected test list, harness adjustments and scripts are retained under `builds/community-backport/`. Archive SHA-256 is in `php-5.6.40-community-backport-Win32-VC11-x86.zip.sha256`. No commit, remote publication or XAMPP deployment was performed.
