# PHP 5.6.40 minimal patch: Windows build record

Built on 25 October 2026 (Asia/Karachi), following `patching-php-5640-for-symfony-14.md` with the minimal patch substituted for the enhanced patch.

## Deliverable

`php-5.6.40-minimal-patch-Win32-VC11-x86.zip`

The ZIP contains a fresh build of original PHP 5.6.40 with `php-5.6-minimal.patch`, CLI and CGI executables, `php5ts.dll`, `php5apache2_4.dll`, snapshot extensions and supporting libraries. Build metadata and copies of the patch are inside `build-info/`. The version remains `5.6.40`; the ZIP name and build metadata identify the patch flavor. No active `php.ini` is supplied.

The existing XAMPP installation was not replaced, reconfigured, stopped or restarted. Its Apache executable was used only for a syntax/module-load check against a separate configuration in this workspace.

## Exact inputs

| Input | Recorded value |
|---|---|
| Original PHP repository | https://github.com/php/php-src.git |
| Original tag | `php-5.6.40` |
| Original source commit | `4b8f72da5dfb201af4e82dee960261d8657e414f` |
| Patch repository | https://github.com/Anton-Barinov/php2shell-patches |
| Patch repository commit | `44d89a8ef15ecaded6ef441b4afea5653eb1f8c9` |
| Patch | `php-5.6-minimal.patch` |
| Original local patch SHA-256 | `7cd5019bd8c372808cd2944771d8a15d50c197ba3dfe2badfb4668076fb1c1a7` |
| Compiler | Microsoft Visual C++ 2012, `17.00.50727.1 for x86` |
| Build type | Release, x86, Thread Safe, MSVC11 |
| SDK | Existing `C:\php-sdk`, `php-sdk-binary-tools-20110915.zip` |
| Dependencies | Existing `C:\php-sdk\phpdev\vc11\x86\deps`, from `deps-5.6-vc11-x86_2018-12.7z` |
| Dependency archive SHA-256 | `641a4f39f7a7fff4fbcfdccabc12e0845b451d8cdb1e834a937488a40b2539ab` |

The patch repository copy had CRLF line endings and the fresh source clone had LF. An additional copy of the patch was normalized to LF, with no code changes, and passed `git apply --check` before application. Both copies and their hashes are preserved under `minimal-build/provenance`. No Remi source or enhanced patch was used.

The final runtime source changes are exactly the five files changed by the patch: `Zend/zend_alloc.c`, `Zend/zend_alloc.h`, `ext/session/session.c`, `main/main.c`, and `main/rfc1867.c`. No additional runtime source adjustments were needed.

## Build procedure

The original source was freshly cloned with:

```bat
git -c core.autocrlf=false clone --depth 1 --branch php-5.6.40 https://github.com/php/php-src.git minimal-build/source
```

The source is in `minimal-build/source`. Compiler and SDK environment setup, configuration, compilation, and packaging are recorded in `minimal-build/build.cmd`:

```bat
minimal-build\build.cmd configure
minimal-build\build.cmd compile
minimal-build\build.cmd package
```

The configure arguments match the guide, with an explicit path to the existing dependencies because this build is inside the workspace:

```bat
configure.bat --enable-snapshot-build --without-analyzer --enable-cli --enable-cgi --enable-session --enable-filter --with-libxml --enable-apache2-4handler --with-php-build=C:\php-sdk\phpdev\vc11\x86\deps
```

Both `nmake` and `nmake snap` completed with exit code 0. The snapshot command emitted the guide's expected empty-PECL archive warning; the main runtime ZIP was created successfully. Missing PDB warnings concern dependency debug symbols. The VC2012 runtime and Windows-system DLL collection warnings are also retained in the packaging log. Do not assume this ZIP includes the VC2012 x86 runtime; it must be available on a destination machine.

`minimal-build/package-and-extract.py` copied the generated runtime archive to its distinct release name, added build provenance, verified ZIP CRCs, and extracted it to `minimal-build/verification-runtime`. Final validation documentation was added as metadata afterward; executable and DLL contents were not changed.

## Validation results

Validation used the extracted ZIP's binaries with `-n`, without loading the installed PHP configuration.

| Check | Result |
|---|---|
| ZIP integrity and required runtime files | Passed |
| CLI version, 32-bit integers, thread safety, built-in session support | Passed |
| CGI multipart fields and file upload, including `is_uploaded_file()` and exact file contents | Passed |
| Multipart request with 3,000 irrelevant MIME headers | Upload and recognized Content-Type preserved |
| Upload progress with its INI value explicitly set to `1` and cleanup disabled | No progress state created; ordinary upload succeeded |
| Session write/read round trip | Passed |
| 16 MB memory limit with a 32 MB allocation | Exit code 1, expected fatal error on stderr, registered shutdown callback did not run |
| Original bundled upload/session regression tests | 35 passed, 1 skipped (debug-only test), 0 warnings, 0 failures |
| Existing Apache 2.4.12 Win32 loading the new PHP module, isolated config, `httpd -t` | `Syntax OK`, exit code 0 |
| Static modules compared with existing XAMPP CLI | No existing static module missing |
| Existing XAMPP runtime hashes compared before/after | Unchanged |

The selected 36 PHPT files and complete results are preserved in `minimal-build/provenance/regression-tests.txt` and `minimal-build/logs/regression.log`. The stock test runner and PHPT expectations were not modified. The three enhanced-patch regression tests from the previous guide do not ship with this minimal patch and were not claimed as tested here.

Smoke-test implementation and results are in `minimal-build/tests/smoke.py` and `minimal-build/logs/smoke-results.json`. The smoke and extension checks removed XAMPP and SDK directories from the subprocess PATH to avoid satisfying dependencies from those installations.

## Optional extensions and limits

Of 32 packaged dynamic extensions, 28 loaded without warnings, including curl, OpenSSL, mbstring, GD, mysqli, PDO MySQL, PostgreSQL, SQLite and OPcache. SNMP loaded but warned that its MIB data was missing. InterBase, PDO Firebird and Sybase CT did not load because their external client DLLs are absent. These optional extensions require their client dependencies/data before enabling them; they are not enabled by a bundled active configuration. Details are in `minimal-build/logs/extensions.json`.

Session upload progress is forcibly disabled by this minimal patch even when `ini_get('session.upload_progress.enabled')` reports `1`. That setting alone cannot identify the compiled behavior. Normal uploads were verified separately.

This is an unofficial community-patched PHP 5.6.40 build with historical dependencies. The checks above are targeted checks, not a complete security audit or the full PHP test suite. Apache syntax/module loading was tested without starting a server; live web requests, concurrent Apache memory-exhaustion behavior, the Symfony application, and external database/service integrations were not tested. The missing/incorrect Content-Length `post_max_size` path was not independently exercised by the Linux-only feedpost extension harness.

## Records

- Runtime archive checksum: `php-5.6.40-minimal-patch-Win32-VC11-x86.zip.sha256`
- Build/configuration/packaging logs: `minimal-build/logs/`
- Exact patches, source diff, revisions, hashes and dependency header inventory: `minimal-build/provenance/`
- Reusable verification scripts and isolated Apache config: `minimal-build/tests/`

The source and verification working trees are excluded from the parent repository's default Git status through `.gitignore`. They remain on disk for inspection. No commit or remote publication was made.
