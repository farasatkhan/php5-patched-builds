# Unofficial PHP 5.5.38 community-backport: Windows build record

Completed 25 October 2026 (Asia/Karachi). Runtime ZIP: `php-5.5.38-community-backport-Win32-VC11-x86.zip`. This is an unofficial community-patched Release build for **VC11, x86, Thread Safe**, with CLI, CGI and the Apache 2.4 handler. No active `php.ini` is bundled. Existing XAMPP files and previous release ZIPs are unchanged, verified against baseline hashes.

## Inputs

- Original PHP source: https://github.com/php/php-src.git, tag `php-5.5.38`, commit `bcd100d812b525c982cf75d6c6dabe839f61634a`.
- Patch: `php-5.5-community-backport.patch` from https://github.com/Anton-Barinov/php2shell-patches, commit `44d89a8ef15ecaded6ef441b4afea5653eb1f8c9`.
- Original local patch SHA-256: `643ae7d624f6efcab76d5a8500efc64df709c4e300849b64c0a57f4876315b9f`.
- LF-normalized applied patch SHA-256: `cf74f542a9a899d9bdccabb4f64538075c76af843ebe578bd94a437bf8d8440d`.
- Compiler: `Microsoft (R) C/C++ Optimizing Compiler Version 17.00.50727.1 for x86`.
- Dependencies: `deps-5.5-vc11-x86.7z`, SHA-256 `1993976945e34e536ef507fd08cff6f39f79475e4af084b16f35f6c4a70118aa`, downloaded from the official PHP archive.
- SDK binary tools: existing `C:\php-sdk` (20110915).
- Session upload progress: **force-disabled**. Ordinary uploads were verified.

## Additional MIME-header correction

The supplied upstream patch advances the header-value pointer twice. The pre-correction upload test preserved file contents but returned `ext/plain` for `Content-Type: text/plain`. The approved one-line `mime-header-value-fix.patch` removes the duplicate advance. The original upstream patch remains unchanged and is included alongside this correction. Correction SHA-256: `32aba402b7b69912d99d2925cc5a4e056db13c18ac5335d7e5525ae5ae56058a`. The combined source diff is preserved separately. Pre-correction artifacts and failing smoke results remain under `legacy-builds/php55-community/pre-correction` where available.

Each patch was applied to a separate clean source checkout. Only patch line endings were normalized. The source diff matches the recorded combined upstream patch and MIME-header correction exactly. Bundled PHPT test inputs and expected results were preserved.

PHP 5.5 uses the installed Visual Studio 2012 compiler.

## Build

For a fresh checkout, apply the named upstream patch and then `mime-header-value-fix.patch` before compiling. The retained working source already includes both.

```bat
legacy-builds\build.cmd php55-community configure
legacy-builds\build.cmd php55-community compile
legacy-builds\build.cmd php55-community package
```

The build enables the snapshot extension set, CLI, CGI, session, filter, libxml and Apache 2.4, with static analysis disabled and compiler concurrency limited to two. Exact configure flags are in `build-info.json`. Compilation runs `nmake`; packaging runs the standard `build-devel` and `build-dist` targets used by the snapshot target. Both stages finished with exit code 0. Complete logs remain under `legacy-builds/php55-community/logs`.

The historical packager may warn about missing dependency debug symbols, an empty PECL archive and system/client DLLs it cannot collect. The main runtime ZIP passed integrity and configured-component checks. A destination machine needs the matching VC++ runtime; the ZIP is not proof that every optional external client dependency is installed.

## Validation

- Six smoke checks passed: reported PHP version, x86/thread safety/session support, Apache module file presence, normal CGI multipart fields and exact uploaded-file contents with 3,000 irrelevant MIME headers, expected progress behavior, session write/read, and memory-limit termination without a registered shutdown callback running.
- Selected original/bundled PHPT tests: **32 passed, 1 skipped, 0 failed, 0 warned**. Skips and platform reasons are recorded in the log.
- Apache 2.4.12 Win32 syntax/module-load check with a separate workspace configuration: `Syntax OK`, exit 0. No Apache server was started or restarted.
- Required session/filter/libxml/PDO modules are present.
- 28/32 packaged extensions loaded without warnings. Exact per-extension stdout/stderr is in `logs/extensions.json`; optional external-client and MIB-data issues are recorded there.
- Final ZIP EXE/DLL bytes match the extracted binaries used for testing; ZIP CRCs and final SHA-256 were verified.
- XAMPP and previous ZIP hashes are unchanged. Runtime code matches the upstream patch plus the documented MIME-header correction; generated comment metadata is audited separately.

Separate Windows test-harness copies used: **no**. Where present, these correct the guide's Windows extension-detection and `proc_open` shell-quoting problems without editing source tests, payloads or expected output. Original harness runs and adjustment diffs are retained.

These are targeted checks, not the full PHP suite or a complete security audit. PHP and dependency versions are historical. Live web requests, concurrent Apache behavior, Symfony acceptance and external database/service integrations were not tested.

## Records

The ZIP contains `build-info/` with exact patches, revisions, compiler identity, source diff, selected test list and validation results. Working sources, complete logs and verification scripts remain under `legacy-builds/php55-community/`. The checksum is in `php-5.5.38-community-backport-Win32-VC11-x86.zip.sha256`. No deployment, commit or remote publication was performed.
